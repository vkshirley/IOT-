#include "Energia.h"

#line 1 "C:/Users/VAIBHAV/workspace_v11/sketch_jul21a/sketch_jul21a.ino"
#include <WiFi.h>
#include <SPI.h>



void setup();
void loop();

#line 6
IPAddress shieldIP,subnetMask,gatewayIP; 
uint8_t rssi;
uint8_t networkId;
byte macAddr[6];
byte encryptionType;


char ssid[]="VK";





void setup() {
  
    Serial.begin(115200);
    
    
    Serial.print("connecting to WIFI..");
    while(WiFi.begin(ssid)!=WL_CONNECTED)
        
    {
        Serial.print(".");
        delay(1);
    }
    Serial.println("");
    Serial.print("Wifi Connected , Fetching Wifi Sheild's IP address :");
    while(WiFi.localIP()==INADDR_NONE){
        Serial.print(".");
        delay(1);
    }
    shieldIP = WiFi.localIP();
    Serial.println(shieldIP);

    Serial.print("Access Point name:");
    Serial.println(ssid);

    Serial.print("Signal Strength");
    rssi=WiFi.RSSI();
    Serial.println(rssi); 

    uint8_t networkId= WiFi.scanNetworks();
    Serial.print("number of access points in range:");
    Serial.println(networkId);
    for(int i=1;i<=networkId;i++){
        Serial.print("Name of Access points and encryption type:");
        Serial.print(WiFi.SSID(i));
        Serial.print(",");
        encryptionType=WiFi.encryptionType(i);
        
        Serial.println(encryptionType,DEC);
    }

    subnetMask = WiFi.subnetMask();
    Serial.print("Subnet Mask:");
    Serial.println(subnetMask);

    gatewayIP=WiFi.gatewayIP();
    Serial.print("Gateway IP Address:");
    Serial.println(gatewayIP);

    WiFi.macAddress(macAddr);
    Serial.print("Mac Address of Sheild:");
    for(int i=0;i<6;i++){
        Serial.print(macAddr[i],HEX);
        if(i<=4)
            Serial.print(':');
        else
            Serial.println();
    }

}

void loop() {
  
  
}



