#include "Energia.h"

#line 1 "C:/Users/VAIBHAV/workspace_v11/wifikal/wifikal.ino"
#include <WiFi.h>
#include <SPI.h>


void setup();
void loop();

#line 5
void setup() {
  

}

void loop() {
  
  
}



