#include "Energia.h"

#line 1 "C:/Users/VAIBHAV/workspace_v11/CloudController/CloudController.ino"
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>

#include <WiFi.h>
#include <SPI.h>
#include <PubSubClient.h>
#include <aJSON.h>


void setup();
void loop();
void callback(char* inTopic,byte* payload,unsigned int length);

#line 9
IPAddress shieldIP,subnetMask,gatewayIP; 
uint8_t rssi;
uint8_t networkId;
byte macAddr[6];
byte encryptionType;

char ssid[]="vivoY73";





WiFiClient wclient;
char server[]="broker.hivemq.com";
PubSubClient client(server,1883,callback,wclient);

char* jsonPayload;



void setup() {
  
    Serial.begin(115200);
    
    
    Serial.print("connecting to WIFI..");
    while(WiFi.begin(ssid)!=WL_CONNECTED)
        
    {
        Serial.print(".");
        delay(1);
    }
    Serial.println("");
    Serial.print("Wifi Connected , Fetching Wifi Sheild's IP address :");
    while(WiFi.localIP()==INADDR_NONE){
        Serial.print(".");
        delay(1);
    }
    shieldIP = WiFi.localIP();
    Serial.println(shieldIP);

    Serial.print("Access Point name:");
    Serial.println(ssid);

    Serial.print("Signal Strength");
    rssi=WiFi.RSSI();
    Serial.println(rssi); 

    uint8_t networkId= WiFi.scanNetworks();
    Serial.print("number of access points in range:");
    Serial.println(networkId);
    for(int i=1;i<=networkId;i++){
        Serial.print("Name of Access points and encryption type:");
        Serial.print(WiFi.SSID(i));
        Serial.print(",");
        encryptionType=WiFi.encryptionType(i);
        Serial.println(encryptionType,HEX);
        
    }

    subnetMask = WiFi.subnetMask();
    Serial.print("Subnet Mask:");
    Serial.println(subnetMask);

    gatewayIP=WiFi.gatewayIP();
    Serial.print("Gateway IP Address:");
    Serial.println(gatewayIP);

    WiFi.macAddress(macAddr);
    Serial.print("Mac Address of Sheild:");
    for(int i=0;i<6;i++){
        Serial.print(macAddr[i],HEX);
        if(i<=4)
            Serial.print(':');
        else
            Serial.println();
    }
    GPIO_setAsOutputPin(GPIO_PORT_P1,GPIO_PIN0);
    GPIO_setAsOutputPin(GPIO_PORT_P2,GPIO_PIN0|GPIO_PIN1|GPIO_PIN2);
    GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P4,GPIO_PIN7,GPIO_TERTIARY_MODULE_FUNCTION);
                                                                                                                
            ADC14_initModule(ADC_CLOCKSOURCE_MCLK,ADC_PREDIVIDER_1,ADC_PREDIVIDER_1,ADC_NOROUTE);
            ADC14_configureSingleSampleMode(ADC_MEM6,true);
            ADC14_configureConversionMemory(ADC_MEM6,ADC_VREFPOS_AVCC_VREFNEG_VSS,ADC_INPUT_A6,false);
            ADC14_setSampleHoldTime(ADC_PULSE_WIDTH_32,ADC_PULSE_WIDTH_4);
            ADC14_setResolution(ADC_12BIT);
            ADC14_enableSampleTimer(ADC_AUTOMATIC_ITERATION);
            ADC14_enableModule();
            ADC14_enableConversion();
            ADC14_toggleConversionTrigger();

}

void loop()
{
    if(!client.connected())
    {
        Serial.println("Disconnected:Reconnecting...");
        if(!client.connect("iloveIndia"))
        {
            Serial.println("connection failed");
        }
        else
        {
            Serial.println("Connection success");
            if(client.subscribe("Mrradha"))
            {
                Serial.println("Subscription sucessfull");
            }
        }
    }

    int result,regressedData1;
    float regressedData;

    while(!ADC14_isBusy());
    result=ADC14_getResult(ADC_MEM6);
    P2OUT=result>>8;
    Serial.println(result);
    ADC14_toggleConversionTrigger();
    
    regressedData=((result*0.786295966)+7.695073417)/1000;
    regressedData1=((result*0.786295966)+7.695073417);
    P2->OUT=result>>8;

    
    String str=(String)regressedData1;
    int str_len=str.length()+2;
    char char_array[str_len];
    str.toCharArray(char_array,str_len);
    char pot_reading[str_len];

    if(regressedData<1)
    {
        pot_reading[0]='0';
        pot_reading[1]='.';
        for(int i=2;i<=str_len;i++)
        {
            pot_reading[i]=char_array[i-2];
        }
    }
    else
    {
        pot_reading[0]=char_array[0];
        pot_reading[1]='.';
        for(int i=2;i<=str_len;i++)
        {
            pot_reading[i]=char_array[i-1];

        }
    }
    
    
    aJsonObject *root=aJson.createObject();
    aJsonObject *d=aJson.createObject();
    aJson.addItemToObject(root,"d",d);
    aJson.addStringToObject(d,"IbmCloudPot","vKPallu");
    aJson.addStringToObject(d,"potValue",pot_reading);
    
    jsonPayload=aJson.print(root)+'\0';

    
    aJson.deleteItem(d);
    aJson.deleteItem(root);
    
    client.publish("radhaMr",jsonPayload);

    client.poll();
    delay(1000);

}

void callback(char* inTopic,byte* payload,unsigned int length)
{
    
    
    
    Serial.print("Message arrived on topic:");
    Serial.print(inTopic);
    Serial.print(". Message:");
    String arrivedMessage;
    
    for(int i=0;i<length;i++)
    {
        Serial.print((char)(payload[i]));
        arrivedMessage+=(char)payload[i];
    }
    Serial.println();
    if(arrivedMessage=="LED1ON")
        GPIO_setOutputHighOnPin(GPIO_PORT_P1,GPIO_PIN0);
    else
        if(arrivedMessage=="LED1OFF")
            GPIO_setOutputLowOnPin(GPIO_PORT_P1,GPIO_PIN0);
}





