#include "Energia.h"

#line 1 "C:/Users/VAIBHAV/workspace_v11/wifi/wifi.ino"
#include <WiFi.h>
#include <SPI.h>


void setup();
void loop();

#line 5
IPAddress shieldIP,subnetMask,gatewayIP;
uint8_t rssi;
uint8_t networkId;
byte macAddr[6];
byte encryptionType;
char ssid[]="Opp";

void setup() {

Serial.begin(115200);
Serial.print("connecting to wifi");
while(WiFi.begin(ssid)!=WL_CONNECTED)

{
Serial.print(".") ;
delay(1); 
}
Serial.println("") ;
Serial.print("Wifi connected ,fetching wifi sheild's IP Address: ");
while(WiFi.localIP()==INADDR_NONE)
{
Serial.print(".") ;
delay(1); 
}
shieldIP = WiFi.localIP();
Serial.println(shieldIP);
Serial.print("Access point name: ");
Serial.println(ssid);
Serial.print("Signal strength: ");
rssi=WiFi.RSSI();
Serial.println(rssi); 
uint8_t networkId=WiFi.scanNetworks();
Serial.print("Number of access points in Range:");
Serial.println(networkId);
for(int i=1;i<=networkId;i++)
{
Serial.print("Name of Access Points and Encryption type:");
Serial.print(WiFi.SSID(1));
Serial.print(",");
encryptionType=WiFi.encryptionType(1);

Serial.println(encryptionType,DEC);
}
subnetMask=WiFi.subnetMask();
Serial.println("Subnet mask: ");
Serial.print(subnetMask);
gatewayIP=WiFi.gatewayIP();
Serial.println("Gateway IP Address: ");
Serial.print(gatewayIP);
WiFi.macAddress(macAddr);
Serial.println("Mac Address of Sheild:");
for(int i=0;i<6;i++)
{
Serial.print(macAddr[i],HEX);
if(i<=4)
Serial.print(':');
else
Serial.println();
}
}
void loop() {

}



